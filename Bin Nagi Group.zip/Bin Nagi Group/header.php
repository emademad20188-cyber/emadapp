<!DOCTYPE html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
    <!-- Cal.com embed -->
    <script type="text/javascript">
      (function (C, A, L) { let p = function (a, ar) { a.q.push(ar); }; let d = C.document; C.Cal = C.Cal || function () { let cal = C.Cal; let ar = arguments; if (!cal.loaded) { cal.ns = {}; cal.q = cal.q || []; d.head.appendChild(d.createElement("script")).src = A; cal.loaded = true; } if (ar[0] === L) { const api = function () { p(api, arguments); }; const namespace = ar[1]; api.q = api.q || []; if(typeof namespace === "string"){cal.ns[namespace] = cal.ns[namespace] || api;p(cal.ns[namespace], ar);p(cal, ["initNamespace", namespace]);} else p(cal, ar); return;} p(cal, ar); }; })(window, "https://app.cal.com/embed/embed.js", "init");
      Cal("init", "15min", {origin:"https://app.cal.com"});
      Cal.ns["15min"]("floatingButton", {"calLink":"emadaddin-rassam-0nuhjp/15min","config":{"layout":"month_view","useSlotsViewOnSmallScreen":"true"},"buttonTextColor":"#BFA163","buttonText":"Book a Cal Now"}); 
      Cal.ns["15min"]("ui", {"cssVarsPerTheme":{"light":{"cal-brand":"#BFA163"},"dark":{"cal-brand":"#111729"}},"hideEventTypeDetails":false,"layout":"month_view"});
    </script>
</head>
<body <?php body_class(); ?> data-lang="en">
<?php wp_body_open(); ?>

<!-- TopBar -->
<div class="topbar">
    <div class="container">
        <div class="topbar-info">
            <span style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-envelope text-gold"></i>
                <a href="mailto:info@binnagigroup.com" class="hover:text-gold">info@binnagigroup.com</a>
            </span>
            <span style="display: none; padding: 0 0.5rem; color: #64748b;" class="d-sm-inline">|</span>
            <span style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-phone-alt text-gold"></i>
                <a href="tel:+8615915732732" dir="ltr" class="hover:text-gold">+86 159 1573 2732</a>
            </span>
        </div>
        <div class="topbar-lang">
            <button data-set-lang="en" class="active">English</button>
            <button data-set-lang="zh">中文</button>
            <button data-set-lang="ar">العربية</button>
        </div>
    </div>
</div>

<!-- Navbar -->
<nav id="navbar" class="navbar">
    <div class="container navbar-container">
        <!-- Logo -->
        <a href="#home" class="logo group">
            <div class="logo-icon">
                <i class="fas fa-cube"></i>
            </div>
            <div class="logo-text">
                <div class="logo-title">مجموعة بن ناجي التجارية</div>
                <div class="logo-subtitle">BIN NAGI GROUP</div>
            </div>
        </a>

        <!-- Desktop Menu -->
        <ul class="nav-menu">
            <li><a href="#home" class="nav-link" data-section="home">
                <span class="lang-content" data-lang="en">Home</span>
                <span class="lang-content" data-lang="zh">首页</span>
                <span class="lang-content" data-lang="ar">الرئيسية</span>
            </a></li>
            <li><a href="#about" class="nav-link" data-section="about">
                <span class="lang-content" data-lang="en">About</span>
                <span class="lang-content" data-lang="zh">关于我们</span>
                <span class="lang-content" data-lang="ar">من نحن</span>
            </a></li>
            <li><a href="#services" class="nav-link" data-section="services">
                <span class="lang-content" data-lang="en">Services</span>
                <span class="lang-content" data-lang="zh">服务</span>
                <span class="lang-content" data-lang="ar">خدماتنا</span>
            </a></li>
            <li><a href="#industries" class="nav-link" data-section="industries">
                <span class="lang-content" data-lang="en">Industries</span>
                <span class="lang-content" data-lang="zh">行业</span>
                <span class="lang-content" data-lang="ar">القطاعات</span>
            </a></li>
            <li><a href="#partners" class="nav-link" data-section="partners">
                <span class="lang-content" data-lang="en">Partners</span>
                <span class="lang-content" data-lang="zh">合作伙伴</span>
                <span class="lang-content" data-lang="ar">للشركاء</span>
            </a></li>
            <li><a href="#contact" class="nav-link" data-section="contact">
                <span class="lang-content" data-lang="en">Contact</span>
                <span class="lang-content" data-lang="zh">联系</span>
                <span class="lang-content" data-lang="ar">اتصل بنا</span>
            </a></li>
        </ul>

        <!-- CTA -->
        <a href="#contact" class="btn-quote">
            <span class="lang-content" data-lang="en">Request Quote</span>
            <span class="lang-content" data-lang="zh">请求报价</span>
            <span class="lang-content" data-lang="ar">طلب عرض سعر</span>
        </a>

        <!-- Mobile Toggle -->
        <button class="mobile-toggle" id="mobile-toggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobile-menu">
        <a href="#home" class="mobile-link">
            <span class="lang-content" data-lang="en">Home</span><span class="lang-content" data-lang="zh">首页</span><span class="lang-content" data-lang="ar">الرئيسية</span>
        </a>
        <a href="#about" class="mobile-link">
            <span class="lang-content" data-lang="en">About</span><span class="lang-content" data-lang="zh">关于我们</span><span class="lang-content" data-lang="ar">من نحن</span>
        </a>
        <a href="#services" class="mobile-link">
            <span class="lang-content" data-lang="en">Services</span><span class="lang-content" data-lang="zh">服务</span><span class="lang-content" data-lang="ar">خدماتنا</span>
        </a>
        <a href="#industries" class="mobile-link">
            <span class="lang-content" data-lang="en">Industries</span><span class="lang-content" data-lang="zh">行业</span><span class="lang-content" data-lang="ar">القطاعات</span>
        </a>
        <a href="#partners" class="mobile-link">
            <span class="lang-content" data-lang="en">Partners</span><span class="lang-content" data-lang="zh">合作伙伴</span><span class="lang-content" data-lang="ar">للشركاء</span>
        </a>
        <a href="#contact" class="mobile-link">
            <span class="lang-content" data-lang="en">Contact</span><span class="lang-content" data-lang="zh">联系</span><span class="lang-content" data-lang="ar">اتصل بنا</span>
        </a>
        <a href="#contact" class="btn-quote-mobile">
            <span class="lang-content" data-lang="en">Request Quote</span><span class="lang-content" data-lang="zh">请求报价</span><span class="lang-content" data-lang="ar">طلب عرض سعر</span>
        </a>
    </div>
</nav>
