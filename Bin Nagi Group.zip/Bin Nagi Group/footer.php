    <!-- FOOTER -->
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <!-- Brand -->
                <div style="grid-column: span 1;">
                    <div class="text-white font-extrabold text-2xl mb-4">BIN NAGI GROUP</div>
                    <p class="mb-6" style="line-height: 1.6;">
                        <span class="lang-content" data-lang="en">Connecting Markets. Delivering Value. Building Trust since 2008.</span>
                        <span class="lang-content" data-lang="zh">连接市场。传递价值。始于2008年的信任。</span>
                        <span class="lang-content" data-lang="ar">نربط الأسواق. نقدم القيمة. نبني الثقة منذ 2008.</span>
                    </p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>

                <!-- Divisions -->
                <div>
                    <h4 class="footer-title">
                        <span class="lang-content" data-lang="en">Divisions</span>
                        <span class="lang-content" data-lang="zh">部门</span>
                        <span class="lang-content" data-lang="ar">الأقسام</span>
                    </h4>
                    <ul class="footer-links">
                        <li><a href="#industries">Solar Energy</a></li>
                        <li><a href="#industries">Medical Equipment</a></li>
                        <li><a href="#industries">Building Materials</a></li>
                        <li><a href="#services">Logistics</a></li>
                    </ul>
                </div>

                <!-- Company -->
                <div>
                    <h4 class="footer-title">
                        <span class="lang-content" data-lang="en">Company</span>
                        <span class="lang-content" data-lang="zh">公司</span>
                        <span class="lang-content" data-lang="ar">الشركة</span>
                    </h4>
                    <ul class="footer-links">
                        <li><a href="#about">About Us</a></li>
                        <li><a href="#partners">Partnership</a></li>
                        <li><a href="#contact">Careers</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>

                <!-- WeChat -->
                <div>
                    <h4 class="footer-title">WeChat / 微信</h4>
                    <button id="open-wechat-footer" class="footer-wechat-btn">
                        <i class="fab fa-weixin"></i>
                    </button>
                </div>
            </div>

            <div style="text-align: center; font-size: 0.875rem; color: var(--color-slate-500);">
                &copy; <?php echo date('Y'); ?> Bin Nagi Group. All Rights Reserved.
            </div>
        </div>
    </footer>

    <!-- Floating Buttons -->
    <div class="floating-btns">
        <a href="https://wa.me/8615915732732" target="_blank" class="float-btn btn-whatsapp">
            <span class="ping-ring"></span>
            <i class="fab fa-whatsapp" style="position: relative; z-index: 10;"></i>
        </a>
        <button id="open-wechat-float" class="float-btn btn-wechat">
            <span class="ping-ring" style="background: rgba(7, 193, 96, 0.3);"></span>
            <i class="fab fa-weixin" style="position: relative; z-index: 10;"></i>
        </button>
    </div>

    <!-- WeChat Modal -->
    <div id="wechat-modal" class="modal-overlay">
        <div class="modal-content">
            <button id="close-wechat" class="close-modal"><i class="fas fa-times"></i></button>
            <h3 class="text-navy font-bold text-xl mb-2">
                <span class="lang-content" data-lang="en">Scan via WeChat</span>
                <span class="lang-content" data-lang="zh">微信扫一扫</span>
                <span class="lang-content" data-lang="ar">امسح الرمز عبر WeChat</span>
            </h3>
            <p class="text-slate-500 text-sm mb-6">
                <span class="lang-content" data-lang="en">Connect with our support team instantly.</span>
                <span class="lang-content" data-lang="zh">即刻联系我们的支持团队。</span>
                <span class="lang-content" data-lang="ar">تواصل مع فريق الدعم فوراً.</span>
            </p>
            <div style="background: #f1f5f9; padding: 1rem; border-radius: 0.5rem; display: inline-block; margin-bottom: 1rem; border: 1px solid #e2e8f0;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://binnagigroup.com/contact" alt="QR Code" style="width: 12rem; height: 12rem; mix-blend-mode: multiply;">
            </div>
            <p class="text-slate-400 text-xs">ID: bin-nagi-support</p>
        </div>
    </div>

    <?php wp_footer(); ?>
    
    <!-- Inline scripts for logic that would normally be in assets/js/main.js, placed here for portability in this output format -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // --- Language Switcher ---
        const langButtons = document.querySelectorAll('[data-set-lang]');
        
        // Load saved language
        const savedLang = localStorage.getItem('binnagi_lang') || 'en';
        setLanguage(savedLang);

        langButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                const lang = btn.getAttribute('data-set-lang');
                setLanguage(lang);
            });
        });

        function setLanguage(lang) {
            document.body.setAttribute('data-lang', lang);
            localStorage.setItem('binnagi_lang', lang);
            
            // Update Active State on Buttons
            langButtons.forEach(btn => {
                if(btn.getAttribute('data-set-lang') === lang) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });

            // Handle RTL/LTR
            if(lang === 'ar') {
                document.documentElement.dir = 'rtl';
            } else {
                document.documentElement.dir = 'ltr';
            }
        }

        // --- Mobile Menu ---
        const mobileToggle = document.getElementById('mobile-toggle');
        const mobileMenu = document.getElementById('mobile-menu');
        const mobileLinks = document.querySelectorAll('.mobile-link, .btn-quote-mobile');

        mobileToggle.addEventListener('click', () => {
            mobileMenu.classList.toggle('open');
            const icon = mobileToggle.querySelector('i');
            if(mobileMenu.classList.contains('open')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });

        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.remove('open');
                mobileToggle.querySelector('i').classList.remove('fa-times');
                mobileToggle.querySelector('i').classList.add('fa-bars');
            });
        });

        // --- Sticky Navbar & Scroll Spy ---
        const navbar = document.getElementById('navbar');
        const navLinks = document.querySelectorAll('.nav-link');
        const sections = document.querySelectorAll('section, .trustbar'); // Trustbar treated as section for offset

        window.addEventListener('scroll', () => {
            // Sticky Nav style
            if(window.scrollY > 20) {
                navbar.classList.add('glass-nav');
            } else {
                navbar.classList.remove('glass-nav');
            }

            // Scroll Spy
            let current = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                if(window.scrollY >= (sectionTop - 200)) {
                    current = section.getAttribute('id');
                }
            });

            navLinks.forEach(link => {
                link.classList.remove('active');
                if(link.getAttribute('data-section') === current) {
                    link.classList.add('active');
                }
            });
        });

        // --- WeChat Modal ---
        const modal = document.getElementById('wechat-modal');
        const openBtns = [document.getElementById('open-wechat-float'), document.getElementById('open-wechat-footer')];
        const closeBtn = document.getElementById('close-wechat');

        openBtns.forEach(btn => {
            if(btn) {
                btn.addEventListener('click', () => {
                    modal.classList.add('open');
                });
            }
        });

        if(closeBtn) {
            closeBtn.addEventListener('click', () => {
                modal.classList.remove('open');
            });
        }

        modal.addEventListener('click', (e) => {
            if(e.target === modal) {
                modal.classList.remove('open');
            }
        });

        // --- Contact Form Mock ---
        const form = document.getElementById('contact-form');
        if(form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const btn = form.querySelector('button');
                const originalText = btn.innerHTML;
                
                // Simulate loading
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

                setTimeout(() => {
                    btn.style.background = '#22c55e'; // Green
                    btn.style.color = 'white';
                    btn.innerHTML = '<i class="fas fa-check"></i> Sent!';
                    form.reset();

                    setTimeout(() => {
                        btn.disabled = false;
                        btn.style.background = ''; // Revert to CSS
                        btn.style.color = '';
                        btn.innerHTML = originalText;
                    }, 3000);
                }, 1500);
            });
        }
    });
    </script>
</body>
</html>
