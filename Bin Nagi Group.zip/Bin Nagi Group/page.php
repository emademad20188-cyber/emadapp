<?php get_header(); ?>

<main class="container section-py" style="min-height: 60vh;">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <header class="entry-header mb-8">
                <?php the_title( '<h1 class="entry-title text-3xl font-bold text-navy">', '</h1>' ); ?>
            </header>

            <div class="entry-content text-slate-600 leading-relaxed">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
