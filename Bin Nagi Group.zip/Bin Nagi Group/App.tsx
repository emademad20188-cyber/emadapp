import React, { useState, useEffect } from 'react';
import { Language } from './types';
import TopBar from './components/TopBar';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustBar from './components/TrustBar';
import About from './components/About';
import Services from './components/Services';
import Industries from './components/Industries';
import Partnership from './components/Partnership';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FloatingButtons from './components/FloatingButtons';
import WeChatModal from './components/WeChatModal';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('en');
  const [isWeChatOpen, setIsWeChatOpen] = useState(false);

  useEffect(() => {
    // Update document title or other meta tags if necessary
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  }, [lang]);

  const getFontClass = () => {
    switch (lang) {
      case 'zh': return 'font-noto';
      case 'ar': return 'font-tajawal';
      default: return 'font-inter';
    }
  };

  const openWeChat = () => setIsWeChatOpen(true);
  const closeWeChat = () => setIsWeChatOpen(false);

  return (
    <div className={`min-h-screen bg-white text-slate-700 ${getFontClass()} selection:bg-gold selection:text-white`}>
      <TopBar lang={lang} setLang={setLang} />
      <Navbar lang={lang} />
      
      <main>
        <Hero lang={lang} />
        <TrustBar lang={lang} />
        <About lang={lang} />
        <Services lang={lang} />
        <Industries lang={lang} />
        <Partnership lang={lang} />
        <Contact lang={lang} />
      </main>

      <Footer lang={lang} openWeChat={openWeChat} />
      <FloatingButtons lang={lang} openWeChat={openWeChat} />
      <WeChatModal isOpen={isWeChatOpen} onClose={closeWeChat} lang={lang} />
    </div>
  );
};

export default App;