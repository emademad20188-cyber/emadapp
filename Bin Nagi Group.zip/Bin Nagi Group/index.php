<?php get_header(); ?>

<main>
    <!-- HERO SECTION -->
    <section id="home" class="hero">
        <div class="hero-bg" style="background-image: url('https://images.unsplash.com/photo-1578575437130-527eed3abbec?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80');"></div>
        <div class="hero-overlay-1"></div>
        <div class="hero-overlay-2"></div>

        <div class="container hero-content">
            <div class="badge animate-fade-in-up">
                <div class="badge-line"></div>
                <div class="badge-text">
                    <span class="lang-content" data-lang="en">Since 2008</span>
                    <span class="lang-content" data-lang="zh">始于 2008 年</span>
                    <span class="lang-content" data-lang="ar">منذ عام 2008</span>
                </div>
            </div>

            <h1 class="hero-title animate-fade-in-up delay-200">
                <span class="lang-content" data-lang="en">Your Strategic Industrial Bridge Between <span class="text-gold">You & China</span></span>
                <span class="lang-content" data-lang="zh">连接您与中国的<br /><span class="text-gold">战略工业桥梁</span></span>
                <span class="lang-content" data-lang="ar">الجسر الصناعي الاستراتيجي بينك وبين <span class="text-gold">الصين</span></span>
            </h1>

            <p class="hero-desc animate-fade-in-up delay-400">
                <span class="lang-content" data-lang="en">We provide end-to-end supply chain solutions, project management, and exclusive agency representation for major Chinese manufacturers in the Middle East.</span>
                <span class="lang-content" data-lang="zh">作为中国大型制造商在中东的独家代理，我们提供端到端的供应链解决方案、项目管理以及强大的政府关系网络。</span>
                <span class="lang-content" data-lang="ar">نقدم حلول سلاسل الإمداد المتكاملة، وإدارة المشاريع، والتمثيل التجاري الحصري لكبرى المصانع الصينية في الشرق الأوسط.</span>
            </p>

            <div class="hero-actions animate-fade-in-up delay-600">
                <a href="#partners" class="btn-hero-primary">
                    <span class="lang-content" data-lang="en">Become a Partner</span>
                    <span class="lang-content" data-lang="zh">成为合作伙伴</span>
                    <span class="lang-content" data-lang="ar">كن شريكاً لنا</span>
                </a>
                <a href="#services" class="btn-hero-secondary">
                    <span class="lang-content" data-lang="en">Explore Services</span>
                    <span class="lang-content" data-lang="zh">探索服务</span>
                    <span class="lang-content" data-lang="ar">خدماتنا</span>
                </a>
            </div>
        </div>

        <div class="scroll-indicator animate-float">
            <a href="#about">
                <span>Scroll</span>
                <i class="fas fa-chevron-down"></i>
            </a>
        </div>
    </section>

    <!-- TRUSTBAR SECTION -->
    <div class="trustbar container">
        <div class="trust-card">
            <div class="trust-grid">
                <div class="stat-item">
                    <div class="stat-val">15+</div>
                    <div class="stat-line"></div>
                    <div class="stat-label">
                        <span class="lang-content" data-lang="en">Years Experience</span>
                        <span class="lang-content" data-lang="zh">年行业经验</span>
                        <span class="lang-content" data-lang="ar">سنوات خبرة</span>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-val">500+</div>
                    <div class="stat-line"></div>
                    <div class="stat-label">
                        <span class="lang-content" data-lang="en">Annual Containers</span>
                        <span class="lang-content" data-lang="zh">年集装箱量</span>
                        <span class="lang-content" data-lang="ar">حاوية سنوياً</span>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-val">50+</div>
                    <div class="stat-line"></div>
                    <div class="stat-label">
                        <span class="lang-content" data-lang="en">Major Projects</span>
                        <span class="lang-content" data-lang="zh">大型项目</span>
                        <span class="lang-content" data-lang="ar">مشروع عملاق</span>
                    </div>
                </div>
                <div class="stat-item">
                    <div class="stat-val">3</div>
                    <div class="stat-line"></div>
                    <div class="stat-label">
                        <span class="lang-content" data-lang="en">Global Offices</span>
                        <span class="lang-content" data-lang="zh">全球办事处</span>
                        <span class="lang-content" data-lang="ar">مكاتب دولية</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ABOUT SECTION -->
    <section id="about" class="section-py">
        <div class="container about-grid">
            <div class="about-img-wrapper order-last lg:order-first">
                <div class="about-img-bg"></div>
                <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80" alt="HQ" class="about-img">
                <div class="float-badge animate-float">
                    <div style="font-size: 2.5rem; font-weight: 800; color: var(--color-gold); margin-bottom: 0.5rem; text-align: center;">#1</div>
                    <div style="font-size: 0.875rem; font-weight: 700; line-height: 1.2; text-align: center;">
                        <span class="lang-content" data-lang="en">Trusted Partner<br>in Yemen</span>
                        <span class="lang-content" data-lang="zh">也门最受信赖<br>的合作伙伴</span>
                        <span class="lang-content" data-lang="ar">الشريك الموثوق<br>في اليمن</span>
                    </div>
                </div>
            </div>

            <div class="order-first lg:order-last">
                <div class="section-label">
                    <span class="lang-content" data-lang="en">About Bin Nagi Group</span>
                    <span class="lang-content" data-lang="zh">关于宾纳吉集团</span>
                    <span class="lang-content" data-lang="ar">عن مجموعة بن ناجي</span>
                </div>
                <h2 class="section-title">
                    <span class="lang-content" data-lang="en">Empowering Trade Through Infrastructure & Integrity</span>
                    <span class="lang-content" data-lang="zh">以基础设施和诚信赋能贸易</span>
                    <span class="lang-content" data-lang="ar">تمكين التجارة عبر البنية التحتية والمصداقية</span>
                </h2>
                
                <div class="about-text">
                    <div class="lang-content" data-lang="en">
                        <p>Established in Guangzhou in 2008, Bin Nagi Group has evolved from a trading company into a multinational industrial conglomerate. We bridge the gap between China's manufacturing might and the developing infrastructure needs of Yemen and the GCC.</p>
                        <p>Unlike simple brokers, we own our supply chain: from warehousing in China to customs clearance agents in Aden and distribution fleets in Sanaa.</p>
                    </div>
                    <div class="lang-content" data-lang="zh">
                        <p>宾纳吉集团于2008年在广州成立，已从一家贸易公司发展成为一家跨国工业集团。我们连接了中国强大的制造能力与也门及海湾合作委员会国家日益增长的基础设施需求。</p>
                        <p>与简单的中介不同，我们拥有自己的供应链：从中国的仓储到亚丁的清关代理，再到萨那的分销车队。</p>
                    </div>
                    <div class="lang-content" data-lang="ar">
                        <p>تأسست مجموعة بن ناجي في قوانغتشو عام 2008، وتطورت من شركة تجارية إلى مجموعة صناعية متعددة الجنسيات. نحن نجسّر الفجوة بين قوة التصنيع الصينية واحتياجات البنية التحتية المتنامية في اليمن والخليج.</p>
                        <p>على عكس الوسطاء التقليديين، نحن نمتلك سلسلة التوريد الخاصة بنا: من التخزين في الصين إلى وكلاء التخليص الجمركي في عدن وأساطيل التوزيع في صنعاء.</p>
                    </div>
                </div>

                <ul class="feature-list">
                    <li>
                        <div class="feature-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en">Registered "Class A" Importer</span>
                        <span class="lang-content" data-lang="zh">注册“A级”进口商资质</span>
                        <span class="lang-content" data-lang="ar">مستورد مسجل "فئة أ"</span>
                    </li>
                    <li>
                        <div class="feature-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en">Financial capabilities for L/C & bulk procurement</span>
                        <span class="lang-content" data-lang="zh">具备信用证（L/C）和批量采购的资金实力</span>
                        <span class="lang-content" data-lang="ar">قدرات مالية للاعتمادات البنكية والشراء بالجملة</span>
                    </li>
                    <li>
                        <div class="feature-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en">Deep government & private sector relationships</span>
                        <span class="lang-content" data-lang="zh">深厚的政府及私营部门关系网</span>
                        <span class="lang-content" data-lang="ar">علاقات عميقة مع القطاعين الحكومي والخاص</span>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <!-- SERVICES SECTION -->
    <section id="services" class="services-section section-py">
        <div class="blob-1"></div>
        <div class="blob-2"></div>
        <div class="container relative z-10">
            <div style="text-align: center; max-width: 48rem; margin: 0 auto 3rem auto;">
                <span class="section-label" style="justify-content: center; display: block; border: none;">
                    <span class="lang-content" data-lang="en">Our Expertise</span>
                    <span class="lang-content" data-lang="zh">我们的专业服务</span>
                    <span class="lang-content" data-lang="ar">خبراتنا</span>
                </span>
                <h2 class="section-title">
                    <span class="lang-content" data-lang="en">Integrated Trade Solutions</span>
                    <span class="lang-content" data-lang="zh">综合贸易解决方案</span>
                    <span class="lang-content" data-lang="ar">حلول تجارية متكاملة</span>
                </h2>
            </div>

            <div class="services-grid">
                <!-- Service 1 -->
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-search-dollar"></i></div>
                    <h3 class="service-title">
                        <span class="lang-content" data-lang="en">Strategic Sourcing</span>
                        <span class="lang-content" data-lang="zh">战略采购</span>
                        <span class="lang-content" data-lang="ar">التوريد الاستراتيجي</span>
                    </h3>
                    <p class="service-desc">
                        <span class="lang-content" data-lang="en">Direct access to factories. We verify capabilities, negotiate volume pricing, and ensure quality control (QC) before shipment.</span>
                        <span class="lang-content" data-lang="zh">直接对接工厂。我们在发货前核实生产能力、谈判批量价格并确保质量控制（QC）。</span>
                        <span class="lang-content" data-lang="ar">وصول مباشر للمصانع. نتحقق من القدرات، ونتفاوض على أسعار الجملة، ونضمن مراقبة الجودة قبل الشحن.</span>
                    </p>
                </div>
                <!-- Service 2 -->
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-ship"></i></div>
                    <h3 class="service-title">
                        <span class="lang-content" data-lang="en">Logistics & Shipping</span>
                        <span class="lang-content" data-lang="zh">物流与运输</span>
                        <span class="lang-content" data-lang="ar">الشحن واللوجستيات</span>
                    </h3>
                    <p class="service-desc">
                        <span class="lang-content" data-lang="en">Sea and air freight consolidation from Guangzhou/Yiwu. We handle the complex documentation required for Yemen ports.</span>
                        <span class="lang-content" data-lang="zh">广州/义乌的海运和空运集货服务。我们处理也门港口所需的复杂文件。</span>
                        <span class="lang-content" data-lang="ar">تجميع الشحن البحري والجوي من قوانغتشو/إيوو. نتولى كافة الوثائق المعقدة المطلوبة للموانئ اليمنية.</span>
                    </p>
                </div>
                <!-- Service 3 -->
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-file-signature"></i></div>
                    <h3 class="service-title">
                        <span class="lang-content" data-lang="en">Customs Clearance</span>
                        <span class="lang-content" data-lang="zh">清关服务</span>
                        <span class="lang-content" data-lang="ar">التخليص الجمركي</span>
                    </h3>
                    <p class="service-desc">
                        <span class="lang-content" data-lang="en">Our local team in Aden and Hodeidah navigates regulations to ensure fast release of goods without demurrage.</span>
                        <span class="lang-content" data-lang="zh">我们在亚丁和荷台达的本地团队熟悉法规，确保货物快速放行，避免滞港费。</span>
                        <span class="lang-content" data-lang="ar">فريقنا المحلي في عدن والحديدة يتعامل مع اللوائح لضمان الإفراج السريع عن البضائع دون غرامات تأخير.</span>
                    </p>
                </div>
                <!-- Service 4 -->
                <div class="service-card">
                    <div class="service-icon"><i class="fas fa-coins"></i></div>
                    <h3 class="service-title">
                        <span class="lang-content" data-lang="en">Financial Facilitation</span>
                        <span class="lang-content" data-lang="zh">金融便利化</span>
                        <span class="lang-content" data-lang="ar">التسهيلات المالية</span>
                    </h3>
                    <p class="service-desc">
                        <span class="lang-content" data-lang="en">Secure payment channels. We facilitate TT transfers and Letters of Credit (L/C) between Yemen and China.</span>
                        <span class="lang-content" data-lang="zh">安全的支付渠道。我们协助处理也门与中国之间的TT转账和信用证（L/C）业务。</span>
                        <span class="lang-content" data-lang="ar">قنوات دفع آمنة. نسهل التحويلات البنكية والاعتمادات المستندية (L/C) بين اليمن والصين.</span>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- INDUSTRIES SECTION -->
    <section id="industries" class="section-py">
        <div class="container">
            <div style="margin-bottom: 3rem;">
                <div class="section-label">
                    <span class="lang-content" data-lang="en">Sectors</span>
                    <span class="lang-content" data-lang="zh">行业领域</span>
                    <span class="lang-content" data-lang="ar">القطاعات</span>
                </div>
                <h2 class="section-title">
                    <span class="lang-content" data-lang="en">Key Industries We Serve</span>
                    <span class="lang-content" data-lang="zh">我们要服务的关键行业</span>
                    <span class="lang-content" data-lang="ar">القطاعات الرئيسية</span>
                </h2>
            </div>

            <div class="industry-grid">
                <!-- Item 1 -->
                <a href="#contact" class="industry-card group">
                    <img src="https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-4.0.3&auto=format&fit=crop&w=2072&q=80" alt="Renewable Energy" class="industry-img">
                    <div class="industry-overlay"></div>
                    <div class="industry-content">
                        <div class="industry-text-wrapper">
                            <h3 class="industry-title">
                                <span class="lang-content" data-lang="en">Renewable Energy</span>
                                <span class="lang-content" data-lang="zh">可再生能源</span>
                                <span class="lang-content" data-lang="ar">الطاقة المتجددة</span>
                            </h3>
                            <p class="industry-desc">
                                <span class="lang-content" data-lang="en">Solar farms, inverters, and lithium storage solutions for Yemen's energy crisis.</span>
                                <span class="lang-content" data-lang="zh">针对也门能源危机的太阳能电站、逆变器和锂电池存储方案。</span>
                                <span class="lang-content" data-lang="ar">مزارع الطاقة الشمسية، والمحولات، وحلول تخزين الليثيوم لأزمة الطاقة.</span>
                            </p>
                            <div class="industry-more">
                                <span class="lang-content" data-lang="en">Discover More</span>
                                <span class="lang-content" data-lang="zh">了解更多</span>
                                <span class="lang-content" data-lang="ar">اكتشف المزيد</span>
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                </a>
                <!-- Item 2 -->
                <a href="#contact" class="industry-card group">
                    <img src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2053&q=80" alt="Medical Supplies" class="industry-img">
                    <div class="industry-overlay"></div>
                    <div class="industry-content">
                        <div class="industry-text-wrapper">
                            <h3 class="industry-title">
                                <span class="lang-content" data-lang="en">Medical Supplies</span>
                                <span class="lang-content" data-lang="zh">医疗物资</span>
                                <span class="lang-content" data-lang="ar">التجهيزات الطبية</span>
                            </h3>
                            <p class="industry-desc">
                                <span class="lang-content" data-lang="en">Supplying hospitals with ISO/CE certified diagnostic machinery and consumables.</span>
                                <span class="lang-content" data-lang="zh">为医院供应通过ISO/CE认证的诊断设备和消耗品。</span>
                                <span class="lang-content" data-lang="ar">تزويد المستشفيات بأجهزة التشخيص والمستهلكات المعتمدة عالمياً.</span>
                            </p>
                            <div class="industry-more">
                                <span class="lang-content" data-lang="en">Discover More</span>
                                <span class="lang-content" data-lang="zh">了解更多</span>
                                <span class="lang-content" data-lang="ar">اكتشف المزيد</span>
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                </a>
                <!-- Item 3 -->
                <a href="#contact" class="industry-card group">
                    <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1974&q=80" alt="Heavy Industry" class="industry-img">
                    <div class="industry-overlay"></div>
                    <div class="industry-content">
                        <div class="industry-text-wrapper">
                            <h3 class="industry-title">
                                <span class="lang-content" data-lang="en">Heavy Industry</span>
                                <span class="lang-content" data-lang="zh">重工业</span>
                                <span class="lang-content" data-lang="ar">الصناعات الثقيلة</span>
                            </h3>
                            <p class="industry-desc">
                                <span class="lang-content" data-lang="en">Production lines, raw materials, and construction machinery.</span>
                                <span class="lang-content" data-lang="zh">生产线、原材料及建筑机械。</span>
                                <span class="lang-content" data-lang="ar">خطوط الإنتاج، المواد الخام، وآليات البناء والتشييد.</span>
                            </p>
                            <div class="industry-more">
                                <span class="lang-content" data-lang="en">Discover More</span>
                                <span class="lang-content" data-lang="zh">了解更多</span>
                                <span class="lang-content" data-lang="ar">اكتشف المزيد</span>
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                </a>
                <!-- Item 4 -->
                <a href="#contact" class="industry-card group">
                    <img src="https://images.unsplash.com/photo-1550009158-9ebf69173e03?ixlib=rb-4.0.3&auto=format&fit=crop&w=2101&q=80" alt="Consumer Electronics" class="industry-img">
                    <div class="industry-overlay"></div>
                    <div class="industry-content">
                        <div class="industry-text-wrapper">
                            <h3 class="industry-title">
                                <span class="lang-content" data-lang="en">Consumer Electronics</span>
                                <span class="lang-content" data-lang="zh">消费电子</span>
                                <span class="lang-content" data-lang="ar">الإلكترونيات</span>
                            </h3>
                            <p class="industry-desc">
                                <span class="lang-content" data-lang="en">Wholesale distribution of phones, accessories, and home appliances.</span>
                                <span class="lang-content" data-lang="zh">手机、配件及家用电器的批发分销。</span>
                                <span class="lang-content" data-lang="ar">توزيع بالجملة للهواتف، الملحقات، والأجهزة المنزلية.</span>
                            </p>
                            <div class="industry-more">
                                <span class="lang-content" data-lang="en">Discover More</span>
                                <span class="lang-content" data-lang="zh">了解更多</span>
                                <span class="lang-content" data-lang="ar">اكتشف المزيد</span>
                                <i class="fas fa-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <!-- PARTNERSHIP SECTION -->
    <section id="partners" class="partnership-section section-py">
        <div class="container partner-grid">
            <div>
                <div class="section-label" style="border: none; padding: 0;">
                    <span class="lang-content" data-lang="en">For Manufacturers</span>
                    <span class="lang-content" data-lang="zh">致制造商</span>
                    <span class="lang-content" data-lang="ar">للمصانع والشركات</span>
                </div>
                <h2 class="section-title" style="color: var(--color-white);">
                    <span class="lang-content" data-lang="en">Partner With Us for Market Dominance</span>
                    <span class="lang-content" data-lang="zh">与我们合作，主导市场</span>
                    <span class="lang-content" data-lang="ar">شاركنا للسيطرة على السوق</span>
                </h2>
                
                <div style="color: var(--color-slate-300); margin-bottom: 2rem;">
                    <p class="lang-content" data-lang="en">Are you a top-tier Chinese manufacturer looking to enter the Yemen and GCC market? Bin Nagi Group is your ideal exclusive agent.</p>
                    <p class="lang-content" data-lang="zh">您是希望进入也门及海湾市场的中国顶级制造商吗？宾纳吉集团是您理想的独家代理。</p>
                    <p class="lang-content" data-lang="ar">هل أنت مصنع عالمي يتطلع لدخول سوق اليمن والخليج؟ مجموعة بن ناجي هي وكيلك الحصري المثالي.</p>
                </div>

                <ul class="partner-features" style="color: var(--color-white);">
                    <li>
                        <div class="partner-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en"><strong>Zero Risk:</strong> We buy inventory upfront or secure via LC.</span>
                        <span class="lang-content" data-lang="zh"><strong>零风险：</strong> 我们预付货款或通过信用证（LC）担保。</span>
                        <span class="lang-content" data-lang="ar"><strong>انعدام المخاطر:</strong> نشتري المخزون مقدماً أو عبر اعتمادات بنكية.</span>
                    </li>
                    <li>
                        <div class="partner-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en"><strong>Network:</strong> Access to 500+ wholesalers and government tenders.</span>
                        <span class="lang-content" data-lang="zh"><strong>销售网络：</strong> 直接触达500+批发商及政府招标项目。</span>
                        <span class="lang-content" data-lang="ar"><strong>شبكة التوزيع:</strong> وصول لأكثر من 500 تاجر جملة ومناقصات حكومية.</span>
                    </li>
                    <li>
                        <div class="partner-icon"><i class="fas fa-check"></i></div>
                        <span class="lang-content" data-lang="en"><strong>Brand Building:</strong> We handle local marketing and Arabic support.</span>
                        <span class="lang-content" data-lang="zh"><strong>品牌建设：</strong> 我们负责本地营销和阿拉伯语售后支持。</span>
                        <span class="lang-content" data-lang="ar"><strong>بناء العلامة التجارية:</strong> نتولى التسويق المحلي والدعم الفني.</span>
                    </li>
                </ul>

                <a href="#contact" class="btn-partner">
                    <span class="lang-content" data-lang="en">Apply for Partnership</span>
                    <span class="lang-content" data-lang="zh">申请合作伙伴关系</span>
                    <span class="lang-content" data-lang="ar">قدم طلب شراكة</span>
                </a>
            </div>

            <div class="partners-box">
                <h3 class="text-white font-bold mb-4" style="border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 1rem;">
                    <span class="lang-content" data-lang="en">Current Partners</span>
                    <span class="lang-content" data-lang="zh">现有合作伙伴</span>
                    <span class="lang-content" data-lang="ar">شركاؤنا الحاليون</span>
                </h3>
                <div class="partner-logos">
                    <div class="partner-logo-item">company name 1</div>
                    <div class="partner-logo-item">company name 2</div>
                    <div class="partner-logo-item">company name 3</div>
                    <div class="partner-logo-item">company name 4</div>
                </div>
                <p class="text-center mt-4 text-sm text-slate-400 italic">
                    <span class="lang-content" data-lang="en">+ 20 more strategic partners globally</span>
                    <span class="lang-content" data-lang="zh">+ 全球 20 多个战略合作伙伴</span>
                    <span class="lang-content" data-lang="ar">+ أكثر من 20 شريك استراتيجي حول العالم</span>
                </p>
            </div>
        </div>
    </section>

    <!-- CONTACT SECTION -->
    <section id="contact" class="section-py" style="background: var(--color-slate-50);">
        <div class="container">
            <div style="text-align: center; margin-bottom: 3rem;">
                <h2 class="section-title">
                    <span class="lang-content" data-lang="en">Contact Global Headquarters</span>
                    <span class="lang-content" data-lang="zh">联系全球总部</span>
                    <span class="lang-content" data-lang="ar">تواصل مع الإدارة العامة</span>
                </h2>
                <div style="width: 6rem; height: 4px; background: var(--color-gold); margin: 1rem auto; border-radius: 2px;"></div>
            </div>

            <div class="contact-grid">
                <!-- China Office -->
                <div class="contact-card">
                    <div class="contact-header">
                        <div class="contact-icon"><i class="fas fa-building"></i></div>
                        <span class="lang-content" data-lang="en">China HQ</span>
                        <span class="lang-content" data-lang="zh">中国总部</span>
                        <span class="lang-content" data-lang="ar">مقر الصين</span>
                    </div>
                    <div class="contact-details">
                        <p><strong>Guangzhou:</strong><br>
                        City Key Tower, Li Gang Nan Wan,<br>
                        Nan An Road, Liwan District.<br>
                        广州市荔湾区南岸路城市钥匙大厦</p>
                        <a href="tel:+8615915732732" style="display: flex; align-items: center; gap: 0.5rem; margin-top: 1rem; color: var(--color-navy); font-weight: 700;">
                            <i class="fas fa-phone text-gold"></i> <span dir="ltr">+86 159 1573 2732</span>
                        </a>
                    </div>
                </div>

                <!-- Yemen Office -->
                <div class="contact-card">
                    <div class="contact-header">
                        <div class="contact-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <span class="lang-content" data-lang="en">Yemen Operations</span>
                        <span class="lang-content" data-lang="zh">也门运营中心</span>
                        <span class="lang-content" data-lang="ar">عمليات اليمن</span>
                    </div>
                    <div class="contact-details">
                        <p><strong>Sanaa / Aden:</strong><br>
                        Main Trade Center St,<br>
                        Near Chamber of Commerce.<br>
                        صنعاء / عدن - بجوار الغرفة التجارية</p>
                        <a href="tel:+96777xxxxxxx" style="display: flex; align-items: center; gap: 0.5rem; margin-top: 1rem; color: var(--color-navy); font-weight: 700;">
                            <i class="fas fa-phone text-gold"></i> <span dir="ltr">+967 77xxxxxxx</span>
                        </a>
                    </div>
                </div>

                <!-- Contact Form -->
                <div class="contact-form-card">
                    <div style="position: absolute; top: 0; right: 0; width: 8rem; height: 8rem; background: rgba(197,160,89,0.1); border-radius: 50%; filter: blur(40px);"></div>
                    
                    <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1.5rem; position: relative; z-index: 10;">
                        <span class="lang-content" data-lang="en">Quick Inquiry</span>
                        <span class="lang-content" data-lang="zh">快速咨询</span>
                        <span class="lang-content" data-lang="ar">استفسار سريع</span>
                    </h3>

                    <form id="contact-form" class="relative z-10">
                        <div class="form-group">
                            <input type="text" name="name" class="form-input" placeholder="Name / 姓名 / الاسم" required>
                            <div class="form-line"></div>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" class="form-input" placeholder="Email / 邮箱 / البريد" required>
                            <div class="form-line"></div>
                        </div>
                        <div class="form-group">
                            <textarea name="message" rows="3" class="form-input" style="resize: none;" placeholder="Message / 留言 / الرسالة" required></textarea>
                            <div class="form-line"></div>
                        </div>
                        <button type="submit" class="btn-submit">
                            <span class="lang-content" data-lang="en">Send Message</span>
                            <span class="lang-content" data-lang="zh">发送信息</span>
                            <span class="lang-content" data-lang="ar">إرسال الرسالة</span>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</main>

<?php get_footer(); ?>
