export type Language = 'en' | 'zh' | 'ar';

export interface BaseProps {
  lang: Language;
}

export interface SetLangProps extends BaseProps {
  setLang: (lang: Language) => void;
}

export interface WeChatProps extends BaseProps {
  openWeChat: () => void;
}
